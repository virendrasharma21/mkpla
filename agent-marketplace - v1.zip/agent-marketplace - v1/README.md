# Agent Marketplace MVP

## 🚀 Overview
A simple platform where users can browse AI agents and hire developers.

---

## 🧰 Requirements
- Node.js (v18+)
- npm

---

## 🪟 Windows 10 Setup Guide

### Step 1: Install Node.js
Download from: https://nodejs.org  
Install LTS version.

### Step 2: Extract Project
Unzip the folder.

### Step 3: Open Terminal
Go inside project folder:
```
cd agent-marketplace
```

### Step 4: Install dependencies
```
npm install
```

### Step 5: Run project
```
npm run dev
```

Open browser:
http://localhost:3000

---

## 🌐 Deployment (Free)
1. Push to GitHub
2. Go to Vercel
3. Import repo
4. Deploy

---

## 💡 How it works
- Browse agents
- Click hire → WhatsApp/email
- Developers submit via form

---

## 📦 Future Improvements
- Add database (Supabase)
- Add login
- Add payments

---

Enjoy building 🚀
