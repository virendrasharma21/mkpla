import agents from "@/data/agents";

export default function AgentDetail({ params }) {
  const agent = agents.find(a => a.id === params.id);

  if (!agent) return <div>Not found</div>;

  return (
    <div>
      <h1>{agent.name}</h1>
      <p>{agent.description}</p>
      <a href={agent.contact}>Hire</a>
    </div>
  );
}
