export const metadata = {
  title: "Agent Marketplace",
  description: "Hire AI agents easily",
};
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}