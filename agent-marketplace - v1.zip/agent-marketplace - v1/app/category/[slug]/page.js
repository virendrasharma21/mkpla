"use client";
import { useParams } from "next/navigation";
import agents from "../../../data/agents";
import AgentCard from "../../../components/AgentCard";

export default function CategoryPage() {
  const params = useParams();
  const slug = params?.slug || "";

  const filtered = agents.filter(
    (a) => a.category.toLowerCase() === slug.toLowerCase()
  );

  return (
    <main
      style={{
        minHeight: "100vh",
        padding: "30px",
        background: "linear-gradient(135deg,#0f172a,#1e293b)",
        color: "white",
      }}
    >
      <h1>{slug} Agents</h1>

      {filtered.length === 0 ? (
        <p>No agents found</p>
      ) : (
        <div
          style={{
            display: "grid",
            gridTemplateColumns:
              "repeat(auto-fit,minmax(220px,1fr))",
            gap: "20px",
          }}
        >
          {filtered.map((a) => (
            <AgentCard key={a.id} agent={a} />
          ))}
        </div>
      )}
    </main>
  );
}