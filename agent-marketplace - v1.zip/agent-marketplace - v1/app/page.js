"use client";
import { useState } from "react";
import Link from "next/link";

export default function Home() {
  const categories = [
    { name: "Chatbots", icon: "💬", slug: "chatbots" },
    { name: "Lead Generation", icon: "📈", slug: "lead-gen" },
    { name: "Automation", icon: "⚙️", slug: "automation" },
    { name: "Fintech", icon: "💰", slug: "fintech" },
  ];

  const [search, setSearch] = useState("");

  const filtered = categories.filter((c) =>
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <main
      style={{
        minHeight: "100vh",
        padding: "30px",
        background: "linear-gradient(135deg,#0f172a,#1e293b)",
        color: "white",
      }}
    >
      <h1 style={{ textAlign: "center" }}>
        Hire AI Agents 🚀
      </h1>

      {/* SEARCH */}
      <input
        placeholder="Search..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{
          width: "100%",
          padding: "10px",
          margin: "20px 0",
          borderRadius: "10px",
          border: "none",
        }}
      />

      {/* GRID */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(auto-fit, minmax(220px,1fr))",
          gap: "20px",
        }}
      >
        {filtered.map((cat, i) => (
          <Link
            key={i}
            href={`/category/${cat.slug}`}
            style={{ textDecoration: "none", color: "white" }}
          >
            <div
              style={{
                padding: "20px",
                borderRadius: "15px",
                background: "rgba(255,255,255,0.05)",
                cursor: "pointer",
              }}
            >
              <div style={{ fontSize: "30px" }}>
                {cat.icon}
              </div>
              <h3>{cat.name}</h3>

              <button
                onClick={(e) => e.preventDefault()}
                style={{
                  marginTop: "10px",
                  padding: "10px",
                  width: "100%",
                  background: "purple",
                  color: "white",
                  border: "none",
                  borderRadius: "8px",
                }}
              >
                View Agents
              </button>
            </div>
          </Link>
        ))}
      </div>
    </main>
  );
}