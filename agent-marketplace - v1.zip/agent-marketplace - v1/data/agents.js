const agents = [
  {
    id: "1",
    name: "Website Chatbot",
    category: "chatbots",
    price: "₹5000",
    description: "AI chatbot for websites",
    developer: "Shubham AI Labs",
  },
  {
    id: "2",
    name: "Lead Generator",
    category: "lead-gen",
    price: "₹8000",
    description: "Auto lead capture bot",
    developer: "GrowthAI",
  },
  {
    id: "3",
    name: "Automation Bot",
    category: "automation",
    price: "₹6000",
    description: "Workflow automation",
    developer: "AutoAI",
  },
];

export default agents;