"use client";
import { useState } from "react";

export default function AgentCard({ agent }) {
  const [show, setShow] = useState(false);
  const [form, setForm] = useState({
    problem: "",
    email: "",
    whatsapp: "",
  });

  const submit = () => {
    const msg = `Hi, I want ${agent.name}

Problem: ${form.problem}
Email: ${form.email}
WhatsApp: ${form.whatsapp}`;

    window.open(
      `https://wa.me/917893456123?text=${encodeURIComponent(
        msg
      )}`
    );
  };

  return (
    <>
      <div
        style={{
          padding: "20px",
          borderRadius: "15px",
          background: "rgba(255,255,255,0.05)",
        }}
      >
        <h3>{agent.name}</h3>
        <p>{agent.description}</p>
        <p>{agent.price}</p>

        <button onClick={() => setShow(true)}>
          Hire Now
        </button>
      </div>

      {show && (
        <div
          style={{
            position: "fixed",
            top: 0,
            width: "100%",
            height: "100%",
            background: "rgba(0,0,0,0.5)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <div
            style={{
              background: "white",
              padding: "20px",
              borderRadius: "10px",
              width: "300px",
            }}
          >
            <h3>Hire {agent.name}</h3>

            <textarea
              placeholder="Problem"
              onChange={(e) =>
                setForm({ ...form, problem: e.target.value })
              }
            />

            <input
              placeholder="Email"
              onChange={(e) =>
                setForm({ ...form, email: e.target.value })
              }
            />

            <input
              placeholder="WhatsApp"
              onChange={(e) =>
                setForm({ ...form, whatsapp: e.target.value })
              }
            />

            <button onClick={submit}>Submit</button>
            <button onClick={() => setShow(false)}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </>
  );
}